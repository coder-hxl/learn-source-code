module.exports = require('@vue/compiler-sfc')
